//
//  MainVM.swift
//  ToDoListCreated2
//
//  Created by Кристина Игоревна on 22.06.2025.
//

import Foundation
import SwiftData
@MainActor
@Observable
class TaskViewModel  {
    
    var taskHolderGar: [Task] = []
    private var modelContext: ModelContext?
    //@Environment(\.modelContext) private var modelContext
    
    func setUp(modelContext: ModelContext) {
        self.modelContext = modelContext
        fetchTasks()
    }
    
    func fetchTasks() {
        guard let modelContext else { return }
        do {
            let descriptor: FetchDescriptor<Task> = FetchDescriptor<Task>(sortBy: [SortDescriptor(\.createdAt, order: .reverse)]) //сортировка в масссиве
            taskHolderGar = try modelContext.fetch(descriptor)
            print("taskHolderGarFetch: ", taskHolderGar)
        } catch {
            print("модель не смогла создаться:  ", error )
        }
        
    }
    
    
    func teskAdd(title: String) {
        guard let modelContext, !title.isEmpty else { return }
        let task: Task = Task(title: title)
        print(task)
        modelContext.insert(task)
        do {
            try modelContext.save()
            taskHolderGar.insert(task, at: 0) // task на 0 позиции
        } catch {
            print("ошибка сохранения: ", error)
        }
        saveContext() // Сохранение изменений
    }

    // Метод для удаления задачи
    func deleteTask(at offsets: IndexSet) {
        for index in offsets {
            let taskToDelete = taskHolderGar[index]
            modelContext?.delete(taskToDelete) // Удаление из контекста
        }
        taskHolderGar.remove(atOffsets: offsets) // Удаление из массива
        saveContext() // Сохранение изменений
    }
    
    func toggleComplited(task: Task) {
        guard let modelContext else { return }
        task.isCompleted.toggle()
        saveContext() // Сохранение изменений
    }
    

    private func saveContext() {
        do {
            try modelContext?.save() // Сохранение изменений в контексте
        } catch {
            print("Ошибка сохранения: \(error.localizedDescription)")
        }
    }
    
}

