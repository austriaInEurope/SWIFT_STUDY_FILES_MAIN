//
//  SettingsM.swift
//  ToDoListcreatedS
//
//  Created by Кристина Игоревна on 29.06.2025.
//

import Foundation
import SwiftUI

struct SettingM: View {
    
    @AppStorage("isDark") private var isDarkMode: Bool = false
    var body: some View {
        
        VStack {
            Toggle("Your light/dark Mode: ", isOn: $isDarkMode)
                .foregroundColor(.gray)
                .preferredColorScheme(isDarkMode ? .dark : .light)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.horizontal, 15)
        
    }
}

#Preview { SettingM() }
