
//
//  SubTitle.swift
//  ToDoListCreated2
//
//  Created by Кристина Игоревна on 22.06.2025.
//

import Foundation

import SwiftUI

//Text("Главное - начать.")
//
//    .font(.system(size: 19))//размер шрифт
//    .frame(maxWidth: .infinity, maxHeight: 47 )//горизонтальное растяжение
//    .background(Color.gray.opacity(0.1))//изменение оттенка цвета 0.15
//    .cornerRadius(10)
//    .foregroundColor(.gray.opacity(0.8))
//    .padding(.bottom, 10)

struct SubTitle: ViewModifier {
    var size: CGFloat = 19
    
    func body(content: Content) -> some View {
        content
            .font(.system(size: size))//размер шрифт
            .frame(maxWidth: .infinity, maxHeight: 47 )//горизонтальное растяжение
            .background(Color.gray.opacity(0.1))//изменение оттенка цвета 0.15
            .cornerRadius(10)
            .foregroundColor(.gray.opacity(0.8))
            .padding(.bottom, 10)
    }
    
}
extension SubTitle {
    //func costomSize(size: )
}
//#Preview {
//    SubTitle()
//}
