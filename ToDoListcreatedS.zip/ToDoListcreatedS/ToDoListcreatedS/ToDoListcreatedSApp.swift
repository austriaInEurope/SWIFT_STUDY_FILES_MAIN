//
//  ToDoListcreatedSApp.swift
//  ToDoListcreatedS
//
//  Created by Кристина Игоревна on 28.06.2025.
//

import SwiftUI

@main
struct ToDoListcreatedSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .modelContainer(for: Task.self)
        }
    }
}
